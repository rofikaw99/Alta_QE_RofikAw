package starter.postcodes;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONObject;

public class putReqres {

    public String URLupdate="https://reqres.in/api/users/2";

    @Step
    public void putNewUser(String name, String job) {
        JSONObject data = new JSONObject();
        data.put("name", name);
        data.put("job", job);

        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(data.toString())
                .log().all()
                .when()
                .post(URLupdate);
    }
    }
