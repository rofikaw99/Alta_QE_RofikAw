package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import static org.hamcrest.Matchers.equalTo;

public class Putstep {
    @Steps
    putReqres putreqres;
    @When("I create new user with name is {string} and job is {string}")
    public void Icreatenewuserwith(String name,String job){
        putreqres.putNewUser(name, job);

    }
    @Then("New user is created")
    public void newuseriscreated(){
        SerenityRest.then()
                .statusCode(201);


    }
    @And("the new username is {string} and job is {string}")
    public void verifynewuser(String name, String job){
        SerenityRest.then()
                .body("name",equalTo(name))
                .body("job",equalTo(job));

    }

}
