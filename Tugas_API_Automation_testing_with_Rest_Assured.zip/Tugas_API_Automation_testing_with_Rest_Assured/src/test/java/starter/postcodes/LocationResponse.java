package starter.postcodes;

public class LocationResponse {
    public static final String COUNTRY = "'country'";
    public static final String FIRST_PLACE_NAME = "'places'[0].'place name'";
}
