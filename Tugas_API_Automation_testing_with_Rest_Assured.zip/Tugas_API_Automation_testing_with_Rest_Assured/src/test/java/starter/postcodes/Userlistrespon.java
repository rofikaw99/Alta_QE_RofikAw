package starter.postcodes;

public class Userlistrespon {
    public static final String firstName = "data.first_name";
    public static final String lastName = "data.last_name";
}
