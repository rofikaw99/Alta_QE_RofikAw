package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import static org.hamcrest.Matchers.equalTo;

public class Reqrespost {
    @Steps
    Reqres reqres;
    @When("I put new user with name is {string} and job is {string}")
    public void icreatenewuser(String name,String job){
        reqres.PostNewUser(name, job);

    }
    @Then("New user is update")
    public void newuserisupdate(){
        SerenityRest.then()
                .statusCode(200);


    }
    @And("New username is {string} and job is {string}")
    public void verifynewuser(String name, String job){
        SerenityRest.then()
                .body("name",equalTo(name))
                .body("job",equalTo(job));

    }
}
