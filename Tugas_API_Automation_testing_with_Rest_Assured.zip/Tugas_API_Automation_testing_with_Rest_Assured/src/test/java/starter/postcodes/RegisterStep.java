package starter.postcodes;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

public class RegisterStep {

    @Step

    public void InputNoHP() {
        // 1. 08986412127117
        // 2. 0886456114327
    }

    @Step
    public void InputNama() {
        //1. Sutarjo
        //2. Mangan
    }

    @Step
    public void InputTanggalLahir() {
        //1. 17 Agustus 1945
        //2. 10 November 1965
    }
}
