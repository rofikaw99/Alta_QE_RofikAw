package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class RegisterStepDefinition {
    @Steps

    RegisterStep registerStep;

    @When("Klik tombol register")
    public void Kliktombolregister(){

    }
    @And("masukkan biodata")
    public void masukkanbiodata(){
        registerStep.InputNoHP();
        registerStep.InputNama();
        registerStep.InputTanggalLahir();
    }
    @And("klik save")
    public void kliksave(){

    }

}
