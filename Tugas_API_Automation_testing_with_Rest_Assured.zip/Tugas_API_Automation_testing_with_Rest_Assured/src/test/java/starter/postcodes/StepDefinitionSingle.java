package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.postcodes.UserList;

import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.hamcrest.Matchers.equalTo;



public class StepDefinitionSingle {

    @Steps
    UserList userList;

    @When("I request single user id {int}")
    public void Irequestsingleuserid(int Number){
        userList.fetchUserList(Number);

    }
    @Then("The system send single user")
    public void Thesystemsendsingle(){

    }
    @And("The user first_name is {string}")
    public void Theuserfirst_nameis (String firstNameInput){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response ->response.body(Userlistrespon.firstName,equalTo(firstNameInput)));
    }
    @And("The user last_name is {string}")
    public void Theuserlast_nameis (String LastNameInput){
        restAssuredThat(response ->response.statusCode(200));
        restAssuredThat(response ->response.body(Userlistrespon.lastName,equalTo(LastNameInput)));
    }

}
