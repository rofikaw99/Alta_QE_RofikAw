package starter.postcodes;

import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

public class Deletestep {
    static String InsertLnik="https://reqres.in/api/users/2";

    @Step
    public void inserttheurl() {
        SerenityRest.given()
                .delete(InsertLnik);
    }
}
