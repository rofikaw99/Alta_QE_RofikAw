package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {

    @When("Padaha halaman login Linkedin")
    public void padaha_halaman_login_linkedin() {
        // Linked.com

    }
    @And("masukkan username")
    public void masukkan_username() {
        // Username ; Udin

    }
    @And("masukkan passoword")
    public void masukkan_passoword() {
        // Password : @singkong757

    }
    @And("klik login button")
    public void klik_login_button() {
        // klik login field

    }
    @Then("Masuk halaman utama Linkedin")
    public void masuk_halaman_utama_linkedin() {
        // Done

    }
}
