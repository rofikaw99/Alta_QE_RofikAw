package starter.postcodes;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.postcodes.UserList;

public class UserStepDefinition {

    @Steps
    UserList userList;

    @When("I request list of user in page {int}")
    public void Irequestlistofuserinpage(int  pageNumber){


    }
    @Then("The system send {int} user in the list")
    public void theSystemSendUserInTheList (int totalUser){

    }
    @And("the first user is {string}")
    public void thefirstuserisMichael (String firstUser){

    }
}
