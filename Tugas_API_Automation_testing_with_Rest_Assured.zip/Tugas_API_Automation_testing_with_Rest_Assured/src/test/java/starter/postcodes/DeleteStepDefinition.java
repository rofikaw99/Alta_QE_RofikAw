package starter.postcodes;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;

import static starter.postcodes.Deletestep.InsertLnik;

public class DeleteStepDefinition {
    @Steps

    Deletestep deletestep;

    @When("I log on reqress link")
    public void Ilogonreqresslink(){

    }
    @And("delete data in the url")
    public void inserttheurl(){
        SerenityRest.given()
                .delete(InsertLnik);
    }
    @And("the the file is delete")
    public void thethefileisdelete(){

    }
}
